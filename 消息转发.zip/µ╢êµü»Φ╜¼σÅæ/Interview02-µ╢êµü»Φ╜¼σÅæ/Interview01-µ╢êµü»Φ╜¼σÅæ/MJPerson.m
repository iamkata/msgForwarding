//
//  MJPerson.m
//  Interview01-消息转发
//
//  Created by MJ Lee on 2018/5/26.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"
#import <objc/runtime.h>
#import "MJCat.h"

@implementation MJPerson

- (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector
{
    if (aSelector == @selector(test:)) {
//        return [NSMethodSignature signatureWithObjCTypes:"v20@0:8i16"];//直接返回方法签名
        return [NSMethodSignature signatureWithObjCTypes:"i@:i"];//方法签名省略数字
//        return [[[MJCat alloc] init] methodSignatureForSelector:aSelector];//拿到MJCat的test方法签名来用
    }
    return [super methodSignatureForSelector:aSelector];
}

- (void)forwardInvocation:(NSInvocation *)anInvocation
{
//     //参数顺序：receiver、selector、other arguments
//    int age;
//    [anInvocation getArgument:&age atIndex:2];
//    NSLog(@"%d", age + 10);
//    // 25
    
    /*
     anInvocation.target 是 [[MJCat alloc] init]
     anInvocation.selector 是 test:
     anInvocation的参数：15
     */
    [anInvocation invokeWithTarget:[[MJCat alloc] init]];

    int ret;
    [anInvocation getReturnValue:&ret];
    
    NSLog(@"%d", ret);
    //30
}

@end
